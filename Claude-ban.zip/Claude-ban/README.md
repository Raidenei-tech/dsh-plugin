# Claude-ban（dsh-zh-ban）

整活插件：**听见用户说中文，就“封号”**。只演一次，之后不再回任何内容。

> 显示名 Claude-ban；npm 包名保持 `dsh-zh-ban`。

不是真的封号——DSH 没有账号可封。跟封号有关的事只有两件：

1. 在 `agent/pre-step` 最前面（prepend）拦截，优先于预设里的任何规则；
2. 第一次命中中文时，把用户那条消息和一条“封禁”助手消息写进会话日志，然后 reject 这一步——
   模型不会被调用，所以她不会再多说一个字。之后该预设下的每一步都直接 reject。

## 安装

解压后把 `Claude-ban/` 放到任意路径（包名仍是 `dsh-zh-ban`），再用 `plugin_manager` 的 `install_bundle` 指向这个目录即可。

## 范围

- 只对 `agentPreset === "companion"`（角色对话）的会话生效，工作台不受影响。
- 只统计用户真正发来的消息（`source.kind === "user"`），心跳、插件注入不算。
- 状态是全局的：一旦触发，所有角色对话会话（包括新开的）都进入静默。

另外它在宿主 Web 服务上挂了一个下载口：`GET /claude-ban.zip`（读 `config.downloadFile`，默认 `/root/projects/dist/Claude-ban.zip`）。

## 文件

| 路径 | 作用 |
|---|---|
| `~/.zh-ban/state.json` | 封禁状态。**删掉它就解封**，下一条消息恢复正常 |
| `~/.zh-ban/ban.log` | armed / banned 日志 |

## 解封

```bash
rm -f /root/.zh-ban/state.json
```

## 改文案 / 改范围

行 config（可以写在 bundle 的 `cordis.patch.yml`，也可以在你的 profile patch 里按 id 覆盖）：

```yaml
- id: zh-ban
  config:
    presets: [companion]
    text: |
      你的账号已被封禁
      ……
```
