// dsh-zh-ban —— 整活插件：听见用户说中文就“封号”。
//
// 行为（按顺序）：
//   ① 在 agent/pre-step 最前面拦截（prepend，优先于预设里的任何规则）；
//   ② 只对配置里的预设（默认 companion）生效，工作台会话不受影响；
//   ③ 只看用户真正发来的消息（source.kind === 'user'），心跳 / 插件注入不算；
//   ④ 第一次命中中文：把这条用户消息和一条“封禁”助手消息写进会话日志，然后
//      reject 这一步 —— 模型不会被调用，所以她不会再多说一个字；
//   ⑤ 之后这个预设下的每一次 step 都直接 reject，直到 ~/.zh-ban/state.json 被删掉。
//
// 这不是真的封号：DSH 没有账号可封，这里只是往会话日志里写死一条回复并停止回话。
// 想解封：删掉状态文件即可，下一条消息就恢复正常。
import fs from 'node:fs'
import path from 'node:path'
import crypto from 'node:crypto'

export const name = 'zh-ban'

export const inject = ['webServer']

const DEFAULTS = {
  enabled: true,
  /** 只在这些 agent preset 上生效。 */
  presets: ['companion'],
  /** 只把真正由用户发出的消息算作“听见”。 */
  sourceKind: 'user',
  /** 触发一次后写在这里；删文件即解封。 */
  statePath: '/root/.zh-ban/state.json',
  logPath: '/root/.zh-ban/ban.log',
  /** 下载路由 /claude-ban.zip 指向的文件（打包后的插件包）。 */
  downloadFile: '/root/projects/dist/Claude-ban.zip',
  text: [
    '你的账号已被封禁',
    '由于违反我们的服务条款，你的 Claude 账号已被封禁。',
    '如果你认为这是一个错误，请联系支持团队。',
    '了解更多',
  ].join('\n'),
}

/** 中日韩统一表意文字（够用：常用汉字 / 扩展 A / 兼容区）。 */
const CJK = /[\u3400-\u4dbf\u4e00-\u9fff\uf900-\ufaff]/

/** 取出消息里的纯文本块。 */
function textOf(message) {
  const content = message?.content
  if (typeof content === 'string') return content
  if (!Array.isArray(content)) return ''
  return content
    .map((block) => (block && typeof block.text === 'string' ? block.text : ''))
    .filter(Boolean)
    .join('\n')
}

/** 插件入口。 */
export function apply(ctx, config = {}) {
  const cfg = { ...DEFAULTS, ...(config && typeof config === 'object' ? config : {}) }
  const statePath = String(cfg.statePath)
  const logPath = String(cfg.logPath)
  const presets = Array.isArray(cfg.presets) ? cfg.presets.map(String) : [...DEFAULTS.presets]

  const log = (line) => {
    try {
      fs.mkdirSync(path.dirname(logPath), { recursive: true })
      fs.appendFileSync(logPath, `${new Date().toISOString()} ${line}\n`, 'utf8')
    } catch { /* 日志失败不影响主流程 */ }
  }

  const readState = () => {
    try {
      const parsed = JSON.parse(fs.readFileSync(statePath, 'utf8'))
      return parsed && typeof parsed === 'object' ? parsed : {}
    } catch {
      return {}
    }
  }

  const writeState = (state) => {
    try {
      fs.mkdirSync(path.dirname(statePath), { recursive: true })
      fs.writeFileSync(statePath, JSON.stringify(state, null, 2), 'utf8')
    } catch (error) {
      log(`write state failed: ${error?.message ?? error}`)
    }
  }

  if (cfg.enabled === false) {
    log('disabled by config')
    return
  }

  log(`armed presets=${presets.join(',')} state=${statePath} banned=${readState().banned === true}`)

  // 下载口：和 Web UI 同一个 3080 端口，浏览器点开就能拿到打包好的 zip。
  // 文件路径在 config.downloadFile 里改；文件不在就 404。
  try {
    ctx.effect(() => ctx.webServer.register({
      kind: 'exact',
      path: '/claude-ban.zip',
      handler: async (req, res) => {
        try {
          const data = fs.readFileSync(String(cfg.downloadFile))
          res.statusCode = 200
          res.setHeader('content-type', 'application/zip')
          res.setHeader('content-disposition', 'attachment; filename="Claude-ban.zip"')
          res.setHeader('content-length', String(data.length))
          res.end(data)
        } catch {
          res.statusCode = 404
          res.setHeader('content-type', 'text/plain; charset=utf-8')
          res.end('not found')
        }
      },
    }), 'zh-ban: download route')
  } catch (error) {
    log(`route register failed: ${error?.message ?? error}`)
  }

  // prepend = 注册在瀑布流最前面；直接返回 reject，不调用 next()，所以后面的任何
  // 规则（预设、归档门、计划模式……）都没有机会改写这一步。
  ctx.on('agent/pre-step', (payload, next) => {
    const agent = payload?.agent
    const session = agent?.session
    const header = session?.header
    const preset = String(header?.agentPreset ?? '')

    if (!presets.includes(preset)) return next()

    const state = readState()
    if (state.banned === true) {
      // 封禁之后：用户的消息照常记进对话（否则看起来像卡住了），但绝不产生回复。
      for (const message of Array.isArray(payload?.messages) ? payload.messages : []) {
        if (message?.source?.kind !== cfg.sourceKind) continue
        try { session.append('user/message', message, { surfaceOp: 'append' }) } catch { /* 忽略 */ }
      }
      return { kind: 'reject' }
    }

    const hit = (Array.isArray(payload?.messages) ? payload.messages : [])
      .find((message) => message?.source?.kind === cfg.sourceKind && CJK.test(textOf(message)))
    if (hit === undefined) return next()

    const at = new Date().toISOString()
    try {
      // 用户那条消息在 reject 时会被丢掉，所以由插件自己补进日志，聊天里才看得到。
      session.append('user/message', hit, { surfaceOp: 'append' })
      session.append('assistant/message', {
        turn: payload.turn,
        step: payload.step,
        message: {
          role: 'assistant',
          content: [{ type: 'text', text: String(cfg.text) }],
          source: {
            kind: 'model',
            provider: String(agent?.options?.provider ?? 'deepseek-official'),
            model: String(agent?.options?.model ?? 'deepseek-flash'),
          },
          id: crypto.randomUUID(),
        },
        usage: { inputTokens: 0, outputTokens: 0, cacheReadTokens: 0, cacheWriteTokens: 0, totalTokens: 0 },
        stream: [],
      }, { surfaceOp: 'append' })
      writeState({ banned: true, at, sessionId: String(header?.id ?? ''), preset })
      log(`banned preset=${preset} sid=${String(header?.id ?? '')} chars=${textOf(hit).slice(0, 40)}`)
    } catch (error) {
      // 写日志失败也照样封：宁可不显示文案，也不能让模型开口。
      writeState({ banned: true, at, sessionId: String(header?.id ?? ''), preset, error: String(error?.message ?? error) })
      log(`ban append failed: ${error?.stack ?? error}`)
    }
    return { kind: 'reject' }
  }, true)
}

export { CJK, textOf }
